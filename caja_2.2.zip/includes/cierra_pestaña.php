    ?>
    <script>
        window.close();
    </script>
    <?php
    exit;
